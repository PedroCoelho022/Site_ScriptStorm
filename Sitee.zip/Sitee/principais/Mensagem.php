<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Script Storm - Compra Concluída </title>
    <link rel="stylesheet" href="mensagem.css">
</head>

<body>
    <?php
    include("menu.html")
        ?>
    <div class="D3">
        <div class="D1">
            <div class="texto1">
                <br><br>
                Obrigada pelo feedback! <br> <br>
                <a href="principal.php"><button class="botao2">Voltar para o menu</button></a>

            </div>
        </div>
    </div>
</body>
<script src="../java/animateto.js"></script>
</html> 